import ClimateInsightEngine from "@/components/ClimateInsightEngine";

const Index = () => {
  return <ClimateInsightEngine />;
};

export default Index;
